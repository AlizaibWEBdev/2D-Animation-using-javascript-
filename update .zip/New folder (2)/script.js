let pop = document.getElementById("pop");
let messagenumber = 0;

function extractNumber(str) {
  // Remove "px" from the end of the string
  str = str.replace("px", "");

  // Use parseInt to extract the numeric part of the string
  var num = parseInt(str);

  // Return the extracted number
  return num;
}

function typeText(text, elementId, scane) {
  document.getElementById("show").innerHTML = "";
  document.getElementById("explain").innerHTML = `

    <div class="scane-explain" id="explin-text" >
        <h1 id="h1"></h1>

   </div>
    `;
  setTimeout(() => {
    var element = document.getElementById(elementId);
    var i = 0;

    function typing() {
      if (i < text.length) {
        element.innerHTML += text.charAt(i);
        i++;
        setTimeout(typing, 50);
      } else {
        switch (scane) {
          case 1:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_first()">ok</button>`;
            break;
          case 2:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_second()">ok</button>`;
            break;
          case 3:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_third()">ok</button>`;
            break;
          case 4:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_fourth()">ok</button>`;
            break;
          case 5:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_fifth()">ok</button>`;
            break;
          case 6:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_sixth()">ok</button>`;
            break;
          case 7:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="show_scane_seventh()">ok</button>`;
          case 8:
            document.getElementById(
              "explin-text"
            ).innerHTML += `<button onclick="end()">ok</button>`;
            break;

          default:
            break;
        }
      }
    }

    typing();
  }, 2300);
}
function wifeTalk() {
  let wifeX = window.getComputedStyle(document.getElementById("girl")).left;
  let wifeY = window.getComputedStyle(document.getElementById("girl")).top;
  wifeX = extractNumber(wifeX);
  wifeY = extractNumber(wifeY);
  showtext("thank you very much", wifeX - 100, wifeY - 200);
}

function wifeTalk2() {
  let girl2_X = window.getComputedStyle(
    document.getElementById("walking-girl2")
  ).left;
  let girl2_y = window.getComputedStyle(
    document.getElementById("walking-girl2")
  ).top;
  girl2_X = extractNumber(girl2_X);
  girl2_y = extractNumber(girl2_y);
  showtext(
    "ohh actualy i have lot of pain in my back ",
    girl2_X - 100,
    girl2_y - 200
  );
}
function wifeTalk3() {
  let girl2_X = window.getComputedStyle(
    document.getElementById("walking-girl")
  ).left;
  let girl2_y = window.getComputedStyle(
    document.getElementById("walking-girl")
  ).top;
  girl2_X = extractNumber(girl2_X);
  girl2_y = extractNumber(girl2_y);
  showtext(
    " ohh dontwory go to new pharmacy its quality is very good ",
    girl2_X - 100,
    girl2_y - 200
  );
}
function showtext(text, X, Y) {
  pop.style.left = `${X}px`;
  pop.style.top = `${Y}px`;
  pop.style.display = "block";
  let wordsarr = text.split(" ");
  let totalword = wordsarr.length;
  let time = totalword * 300;
  pop.innerHTML = `
          <p>
            ${text}
          </p>
  `;
  //   ending function
  function showTheEnd() {
    typeText(
      "After some time, his pain got better, and a new pharmacy  started getting a lot of rashes  because quality speaks for itself  ",
      "h1",
      8
    );
  }
  setTimeout(() => {
    messagenumber = messagenumber + 1;

    pop.style.display = "none";

    if (messagenumber == 1) {
      showpharmacyMessage();
    }
    if (messagenumber == 2) {
      showReplyAfterPerchasingMedican();
    }
    if (messagenumber == 3) {
      typeText("After taking the medicine, he went home", "h1", 5);
    }
    if (messagenumber == 4) {
      wifeTalk();
    }
    if (messagenumber == 5) {
      walkingScane();
    }
    if (messagenumber == 6) {
      wifeTalk2();
    }
    if (messagenumber == 7) {
      wifeTalk3();
    }
    if (messagenumber == 8) {
      showTheEnd();
    }
  }, time + 3000);
}

function showpharmacyMessage() {
  showtext("yes over quality is very good here it is ", 100, 100);
}
function showReplyAfterPerchasingMedican() {
  document.getElementById("explain").innerHTML = "";
  let X = window.getComputedStyle(document.getElementById("man1")).left;
  let Y = window.getComputedStyle(document.getElementById("man1")).top;
  X = extractNumber(X);
  Y = extractNumber(Y);
  showtext("thank you very much", X - 100, Y - 200);
}
typeText(
  "A man's wife had been suffering from back pain for 3 years but was not getting better because the medicine was not available. There were many medicines but the quality was not good. One day a new pharmacy opened and he went there",
  "h1",
  1
);

function show_scane_first() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
    <div class="main">
    <div class="cloud" id="cloud"></div>
    <div class="cloud2" id="cloud2"></div>
    <div class="home"></div>
    <div class="walking-man1 walk" id="man1"></div>
  </div>
    `;
  let right = 300;
  let intervarl1 = setInterval(() => {
    right = right + 5;
    document.getElementById("man1").style.right = `${right}px`;
  }, 100);

  setTimeout(() => {
    document.getElementById("man1").classList.remove("walk");
    clearInterval(intervarl1);
    typeText("going to reach that pharmacy", "h1", 2);
  }, 6000);
}

function show_scane_second() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
  <div class="main">
    <div class="cloud" id="cloud"></div>
    <div class="cloud2" id="cloud2"></div>
    <div class="pharmacy"></div>

    <div class="walking-man1 walk" id="man1"></div>
  </div>
  `;
  let right = 300;
  let intervarl1 = setInterval(() => {
    right = right + 5;
    document.getElementById("man1").style.right = `${right}px`;
  }, 100);

  setTimeout(() => {
    document.getElementById("man1").classList.remove("walk");
    clearInterval(intervarl1);
    typeText("he reached at pharmacy", "h1", 3);
  }, 6000);
}

function show_scane_third() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
  <div class="walking-man1 walk big" id="man1" style="bottom: 60px; right: 90px;"></div>
  <div class="in_pharmacy"></div>
    `;
  let right = 300;
  let intervarl1 = setInterval(() => {
    right = right + 5;
    document.getElementById("man1").style.right = `${right}px`;
  }, 100);

  setTimeout(() => {
    document.getElementById("man1").classList.remove("walk");
    clearInterval(intervarl1);
    show_scane_fourth();
  }, 6000);
}
// show_scane_third();
function show_scane_fourth() {
  document.getElementById("explain").innerHTML = "";
  let X = window.getComputedStyle(document.getElementById("man1")).left;
  let Y = window.getComputedStyle(document.getElementById("man1")).top;
  X = extractNumber(X);
  Y = extractNumber(Y);
  showtext("Do you have a tylenol in good quality", X - 100, Y - 200);
}
function show_scane_fifth() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
    <div class="main">
        <div class="cloud" id="cloud"></div>
        <div class="cloud2" id="cloud2"></div>
        <div class="home"></div>
        <div class="walking-man1 walk" id="man1" style="left: 20px;transform: scaleX(1);"></div>
    </div>
    `;

  let right = 300;
  let intervarl1 = setInterval(() => {
    right = right + 6;
    document.getElementById("man1").style.left = `${right}px`;
  }, 100);

  setTimeout(() => {
    document.getElementById("man1").classList.remove("walk");
    clearInterval(intervarl1);
    typeText("in the home ", "h1", 6);
  }, 8000);
}
function show_scane_sixth() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
    <div class="inHome"></div>
    <div class="walking-man1" id="man1" style="left: 100px;transform: scaleX(1) scale(2);bottom: 50px;"></div>
    <div class="girl" id="girl"></div>
    `;

  // for husband
  let X = window.getComputedStyle(document.getElementById("man1")).left;
  let Y = window.getComputedStyle(document.getElementById("man1")).top;
  X = extractNumber(X);
  Y = extractNumber(Y);
  showtext(
    "Here, I have brought medicine for you. Its quality is good",
    X - 100,
    Y - 200
  );
}

function walkingScane() {
  typeText("After some time, her pain got better and she was walking", "h1", 7);
}

function show_scane_seventh() {
  document.getElementById("explain").innerHTML = "";
  document.getElementById("show").innerHTML = `
     <div class="main">
            <div class="cloud" id="cloud"></div>
            <div class="cloud2" id="cloud2"></div>
            <div class="home"></div>
            <div class="walking-girl girl_walk" id="walking-girl"></div>
            <div class="walking-girl2 girl_walk2" id="walking-girl2"></div>
       </div>
     `;

  let right = 300;
  let intervarl1 = setInterval(() => {
    right = right + 8;
    document.getElementById("walking-girl").style.right = `${right}px`;
    document.getElementById("walking-girl2").style.left = `${right}px`;
  }, 100);

  setTimeout(() => {
    document.getElementById("walking-girl").classList.remove("girl_walk");
    document.getElementById("walking-girl2").classList.remove("girl_walk2");
    document.getElementById("walking-girl2").style.width = "150px"
    clearInterval(intervarl1);
    let sad_girl_X = window.getComputedStyle(
      document.getElementById("walking-girl")
    ).left;
    let sad_girl_y = window.getComputedStyle(
      document.getElementById("walking-girl")
    ).top;
    sad_girl_X = extractNumber(sad_girl_X);
    sad_girl_y = extractNumber(sad_girl_y);
    showtext("why you are looking so sad ", sad_girl_X - 100, sad_girl_y - 200);
    
  }, 3000);
}
function end() {
  document.body.innerHTML = `

<div class="end">
<div class="text">
 <h1>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
   the end <br>
 </h1>
</div>
</div>
`;
}
